package com;

/**
 * @author Yifei.Hu
 * @create 2021-09--10:09
 */
public class LoveThreeThousands {
    public static void main(String[] args) {
       int num1=10;
       int num2=3;
       double real1=10;
        double real2=3;
        System.out.println("num1 + num2 = "+(num1+num2));
        System.out.println("num1 / num2 = "+(num1/num2));

        System.out.println("real1 + real2 = "+(real1+real2));
        System.out.println("real1 / real2 = "+(real1/real2));
    }
}
