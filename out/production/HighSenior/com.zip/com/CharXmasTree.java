package com;

/**
 * @author Yifei.Hu
 * @create 2021-09--00:34
 */
public class CharXmasTree {
    public static void main(String[] args) {
        System.out.println("   *");
        System.out.println("  / \\");
        System.out.println(" /   \\");
        System.out.println("/     \\");
        System.out.println("--| |--");
        System.out.println("-------");
    }
}
